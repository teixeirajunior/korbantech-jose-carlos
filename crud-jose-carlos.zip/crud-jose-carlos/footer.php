<footer class="container-fluid text-center">
  <p>José Carlos Teixeira Junior</p>
</footer>

</body>
</html>
